import os
import re

import cv2
import numpy as np

from .config import TEAM_ABBREVIATIONS, TEAM_NAME_ALIASES, TEAM_TYPE


# ============================================================
# Color helpers
# ============================================================

def bgr_to_lab_color(bgr):
    pixel = np.uint8([[bgr]])
    lab = cv2.cvtColor(pixel, cv2.COLOR_BGR2LAB)
    return lab[0, 0].astype(np.float32)


def describe_lab_color(lab):
    l, a, b = float(lab[0]), float(lab[1]), float(lab[2])
    if l < 35:
        return "Black/Dark"
    if l > 200:
        return "White/Light"
    if a > 150:
        return "Red"
    if a < 110:
        return "Green"
    if b > 150:
        return "Yellow"
    if b < 110:
        return "Blue"
    return "Mid-tone"


# ============================================================
# Text normalization
# ============================================================

def normalize_text(text):
    text = text.strip()
    text = re.sub(r"[^\w\s\-&.']", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text


# ============================================================
# Abbreviation disambiguation
# ============================================================

def _pick_from_candidates(candidates, preferred_type=None):
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    if preferred_type:
        typed = [c for c in candidates if TEAM_TYPE.get(c) == preferred_type]
        if typed:
            return typed[0]
    return candidates[0]


def _infer_context(left_candidates, right_candidates):
    left_types = {TEAM_TYPE.get(c) for c in left_candidates} if left_candidates else set()
    right_types = {TEAM_TYPE.get(c) for c in right_candidates} if right_candidates else set()

    if left_candidates and len(left_candidates) == 1 and "international" in left_types:
        return "international"
    if right_candidates and len(right_candidates) == 1 and "international" in right_types:
        return "international"
    if left_candidates and len(left_candidates) == 1 and "club" in left_types:
        return "club"
    if right_candidates and len(right_candidates) == 1 and "club" in right_types:
        return "club"
    if "international" in left_types and "international" in right_types:
        return "international"
    if "club" in left_types and "club" in right_types:
        return "club"
    return None


def abbreviations_to_teams(left_abbr, right_abbr):
    """Resolve two abbreviations to canonical team name STRINGS."""
    left_candidates = TEAM_ABBREVIATIONS.get(left_abbr, [])
    right_candidates = TEAM_ABBREVIATIONS.get(right_abbr, [])
    context = _infer_context(left_candidates, right_candidates)
    left_team = _pick_from_candidates(left_candidates, preferred_type=context)
    right_team = _pick_from_candidates(right_candidates, preferred_type=context)
    return left_team, right_team


# ============================================================
# OCR — focused on broadcast scorebug (NOT YouTube title)
# ============================================================

def extract_scorebug_abbreviations(frame):
    """
    OCR the broadcast scorebug to find two 3-letter team abbreviations.
    """
    try:
        import pytesseract
    except ImportError:
        return "", ""

    height, width = frame.shape[:2]

    scorebug_regions = [
        # Tight narrow bands where scorebugs live
        (0.00, 0.20, 0.03, 0.07),
        (0.00, 0.20, 0.05, 0.09),
        (0.00, 0.20, 0.07, 0.11),
        (0.00, 0.25, 0.03, 0.07),
        (0.00, 0.25, 0.04, 0.08),
        (0.00, 0.25, 0.05, 0.09),
        (0.00, 0.25, 0.06, 0.10),
        (0.00, 0.25, 0.07, 0.11),
        (0.00, 0.30, 0.03, 0.08),
        (0.00, 0.30, 0.05, 0.10),
        (0.00, 0.30, 0.06, 0.11),
        (0.00, 0.30, 0.07, 0.12),
        (0.00, 0.35, 0.04, 0.09),
        (0.00, 0.35, 0.06, 0.11),
        (0.00, 0.35, 0.07, 0.12),
        (0.25, 0.75, 0.03, 0.08),
    ]

    for x_start_pct, x_end_pct, y_start_pct, y_end_pct in scorebug_regions:
        x1 = int(width * x_start_pct)
        x2 = int(width * x_end_pct)
        y1 = int(height * y_start_pct)
        y2 = int(height * y_end_pct)

        crop = frame[y1:y2, x1:x2]
        if crop.size == 0:
            continue

        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)

        # Upscale for small text
        crop_height = y2 - y1
        scale = max(2, int(100 / max(crop_height, 1)))
        gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)

        # Preprocessing variants
        images_to_try = []

        _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        images_to_try.append(thresh)

        _, thresh_inv = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        images_to_try.append(thresh_inv)

        for t in [120, 140, 160, 180, 200]:
            _, fixed = cv2.threshold(gray, t, 255, cv2.THRESH_BINARY)
            images_to_try.append(fixed)
            _, fixed_inv = cv2.threshold(gray, t, 255, cv2.THRESH_BINARY_INV)
            images_to_try.append(fixed_inv)

        psm_modes = ["--psm 7", "--psm 6"]

        for img in images_to_try:
            for psm in psm_modes:
                try:
                    # NO whitelist — let tesseract read freely, we filter after
                    text = pytesseract.image_to_string(img, config=f"{psm} --oem 3")
                except Exception:
                    continue

                text = text.strip()
                if not text:
                    continue

                # Basic sanity: not absurdly long
                if len(text) > 100:
                    continue

                # Find 3-letter tokens that are valid team abbreviations
                tokens = re.findall(r"[A-Z]{3}", text.upper())
                found = []
                for token in tokens:
                    if token in TEAM_ABBREVIATIONS and token not in found:
                        found.append(token)
                        if len(found) >= 2:
                            print(
                                f"[OCR scorebug] Found {found} in region "
                                f"x={x_start_pct:.0%}-{x_end_pct:.0%} "
                                f"y={y_start_pct:.0%}-{y_end_pct:.0%} "
                                f"psm={psm}: {repr(text[:60])}"
                            )
                            return found[0], found[1]

    print("[OCR scorebug] No valid abbreviations found in any region")
    return "", ""
def extract_scoreboard_text(frame):
    """OCR the scorebug area and return raw text (for fallback matching)."""
    try:
        import pytesseract
    except ImportError:
        return ""

    height, width = frame.shape[:2]
    # Read from 3% to 15% height — skip YouTube bar at top
    y1 = int(height * 0.03)
    y2 = int(height * 0.15)
    strip = frame[y1:y2, 0:width]
    gray = cv2.cvtColor(strip, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    try:
        text = pytesseract.image_to_string(gray, config="--psm 6")
    except Exception:
        text = ""
    return text


# ============================================================
# Team name extraction from text
# ============================================================

def extract_team_names_from_text(text):
    """
    Extract up to 2 team names from arbitrary text.
    Aliases checked first. Abbreviation tokens inside already-matched
    alias spans are skipped to prevent false positives like
    'NEW' from 'New Zealand' matching Newcastle.
    """
    if not text:
        return []

    normalized = normalize_text(text)
    found_names = []
    matched_spans = []

    # Check aliases FIRST (longest match first)
    lowered = normalized.lower()
    alias_hits = []
    for alias, team_name in sorted(
        TEAM_NAME_ALIASES.items(), key=lambda item: len(item[0]), reverse=True,
    ):
        if len(alias) < 3:
            continue
        match_index = lowered.find(alias)
        if match_index >= 0:
            # Check this isn't overlapping an already-found longer alias
            span_end = match_index + len(alias)
            overlaps_existing = False
            for s, e in matched_spans:
                if match_index < e and span_end > s:
                    overlaps_existing = True
                    break
            if not overlaps_existing and team_name not in found_names:
                alias_hits.append((match_index, team_name, match_index, span_end))

    for match_index, team_name, span_start, span_end in sorted(alias_hits):
        if team_name not in found_names:
            found_names.append(team_name)
            matched_spans.append((span_start, span_end))
        if len(found_names) >= 2:
            return found_names[:2]

    # Then check abbreviations — skip tokens inside already-matched spans
    upper = normalized.upper()
    for match in re.finditer(r"\b[A-Z]{2,4}\b", upper):
        token = match.group()
        token_start = match.start()
        token_end = match.end()

        # Skip if inside an already-matched alias span
        inside_span = False
        for span_start, span_end in matched_spans:
            if token_start >= span_start and token_end <= span_end:
                inside_span = True
                break
        if inside_span:
            continue

        candidates = TEAM_ABBREVIATIONS.get(token, [])
        if candidates:
            team_name = candidates[0] if isinstance(candidates, list) else candidates
            if team_name not in found_names:
                found_names.append(team_name)
        if len(found_names) >= 2:
            break

    return found_names[:2]


def extract_team_names_from_scoreboard_text(text):
    """Extract team names from scoreboard OCR text with context-aware disambiguation."""
    if not text:
        return []

    normalized = normalize_text(text).upper()
    found_abbrs = re.findall(r"\b[A-Z]{2,4}\b", normalized)
    valid_abbrs = [f for f in found_abbrs if f in TEAM_ABBREVIATIONS]

    if len(valid_abbrs) >= 2:
        left_team, right_team = abbreviations_to_teams(valid_abbrs[0], valid_abbrs[1])
        results = []
        if left_team:
            results.append(left_team)
        if right_team and right_team != left_team:
            results.append(right_team)
        if len(results) >= 2:
            return results[:2]

    # Fall back to full-name matching
    return extract_team_names_from_text(text)


# ============================================================
# Video path / frame helpers
# ============================================================

def get_video_path(video_input):
    if video_input is None:
        return None
    if isinstance(video_input, str):
        return video_input if video_input else None
    if isinstance(video_input, dict):
        path = video_input.get("video", video_input.get("name", ""))
        return path if path else None
    path = str(video_input)
    return path if path and path != "None" else None


def read_first_frame(video_path):
    if not video_path:
        return None
    cap = cv2.VideoCapture(video_path)
    ret, frame = cap.read()
    cap.release()
    return frame if ret else None


# ============================================================
# Matchup resolution
# ============================================================

def resolve_matchup(video_path):
    """
    Detect the two teams. Strategy:
    1. Try filename first (most reliable for downloaded clips)
    2. Then try OCR from scorebug (works for clean broadcast graphics)
    """
    if not video_path:
        return [], "no video"

    # --- FILENAME FIRST (fast, reliable for YouTube/downloaded clips) ---
    fallback_names, fallback_source = _fallback_from_filename(video_path)
    if len(fallback_names) >= 2:
        # Verify with OCR if possible, but filename is already good
        return fallback_names[:2], fallback_source

    # --- Then try OCR ---
    team_names = list(fallback_names)  # start with whatever filename found
    source = fallback_source if fallback_names else "unknown"

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return team_names[:2], source

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    sample_indices = [int(total_frames * f) for f in [0.02, 0.05, 0.08, 0.12, 0.15, 0.2]]

    for idx in sample_indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = cap.read()
        if not ret:
            continue

        left_abbr, right_abbr = extract_scorebug_abbreviations(frame)
        if left_abbr and right_abbr:
            left_team, right_team = abbreviations_to_teams(left_abbr, right_abbr)
            team_names = []
            for team_name in [left_team, right_team]:
                if team_name and team_name not in team_names:
                    team_names.append(team_name)
            if len(team_names) >= 2:
                source = "OCR (abbreviation)"
                break

    cap.release()

    if len(team_names) < 2:
        source = "fallback"

    return team_names[:2], source


def _fallback_from_filename(video_path):
    """Extract team names from the video filename."""
    basename = os.path.splitext(os.path.basename(video_path))[0]
    names = extract_team_names_from_text(basename)
    if len(names) >= 2:
        return names[:2], "filename"
    return names, "filename"


# ============================================================
# User team query resolution
# ============================================================

def resolve_requested_team(team_query, team_names):
    """Resolve user's team query against detected team names."""
    if not team_query or not team_names:
        return None

    query_matches = extract_team_names_from_text(team_query)
    if query_matches:
        for match in query_matches:
            if match in team_names:
                return match

    # Try abbreviation lookup
    abbr_key = team_query.strip().upper()
    candidates = TEAM_ABBREVIATIONS.get(abbr_key, [])
    for candidate in candidates:
        if candidate in team_names:
            return candidate

    # Try alias lookup
    alias_match = TEAM_NAME_ALIASES.get(team_query.strip().lower())
    if alias_match and alias_match in team_names:
        return alias_match

    # Substring match
    for name in team_names:
        if team_query.strip().lower() in name.lower():
            return name

    return team_names[0] if team_names else None